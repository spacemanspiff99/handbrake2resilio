import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor for logging
api.interceptors.request.use(
  (config) => {
    console.log(`API Request: ${config.method?.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => {
    console.error('API Request Error:', error);
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    console.error('API Response Error:', error.response?.data || error.message);
    return Promise.reject(error);
  }
);

// Tabs API
export const tabsAPI = {
  getTabs: () => api.get('/api/tabs'),
  createTab: (data) => api.post('/api/tabs', data),
  updateTab: (id, data) => api.put(`/api/tabs/${id}`, data),
  deleteTab: (id) => api.delete(`/api/tabs/${id}`),
  getTabSettings: (id) => api.get(`/api/tabs/${id}/settings`),
};

// Queue API
export const queueAPI = {
  getQueueStatus: () => api.get('/api/queue'),
  addToQueue: (data) => api.post('/api/queue', data),
  getAllJobs: () => api.get('/api/queue/jobs'),
  getJob: (id) => api.get(`/api/queue/jobs/${id}`),
  cancelJob: (id) => api.delete(`/api/queue/jobs/${id}`),
  retryJob: (id) => api.post(`/api/queue/jobs/${id}/retry`),
  clearCompletedJobs: () => api.post('/api/queue/clear'),
  pauseQueue: () => api.post('/api/queue/pause'),
  resumeQueue: () => api.post('/api/queue/resume'),
};

// System API
export const systemAPI = {
  getHealth: () => api.get('/api/system/health'),
  getSystemLoad: () => api.get('/api/system/load'),
  getProcesses: () => api.get('/api/system/processes'),
  getRecentLogs: () => api.get('/api/system/logs'),
  getConfig: () => api.get('/api/system/config'),
  getDiskUsage: () => api.get('/api/system/disk'),
};

// Content API (placeholder for future implementation)
export const contentAPI = {
  getContent: (tabId) => api.get(`/api/content/${tabId}`),
  scanContent: () => api.post('/api/system/scan'),
};

export default api;