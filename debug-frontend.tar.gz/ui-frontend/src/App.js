import React from 'react';
import { Toaster } from 'react-hot-toast';
import { QueryClient, QueryClientProvider } from 'react-query';
import { Route, BrowserRouter as Router, Routes } from 'react-router-dom';

import Dashboard from './components/Dashboard';
import Header from './components/Header';
import QueueView from './components/QueueView';
import Sidebar from './components/Sidebar';
import SystemView from './components/SystemView';

// Create a client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
      staleTime: 30000, // 30 seconds
    },
  },
});

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div style={{padding: '20px', textAlign: 'center'}}>
        <h1>🎉 HandBrake2Resilio UI is Loading...</h1>
        <p>API URL: {process.env.REACT_APP_API_URL || 'http://localhost:8080'}</p>
        <p>Build Time: {new Date().toISOString()}</p>
        <div style={{marginTop: '20px', padding: '10px', backgroundColor: '#f0f0f0', borderRadius: '5px'}}>
          <p>Debug Info:</p>
          <p>NODE_ENV: {process.env.NODE_ENV}</p>
          <p>REACT_APP_WS_URL: {process.env.REACT_APP_WS_URL}</p>
        </div>
      </div>
    </div>
  );
  
  // Commented out temporarily for debugging
  /*
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Header />
          <div className="flex">
            <Sidebar />
            <main className="flex-1 p-6">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/queue" element={<QueueView />} />
                <Route path="/system" element={<SystemView />} />
              </Routes>
            </main>
          </div>
          <Toaster
            position="top-right"
            toastOptions={{
              duration: 4000,
              style: {
                background: '#363636',
                color: '#fff',
              },
            }}
          />
        </div>
      </Router>
    </QueryClientProvider>
  );
  */
}

export default App;